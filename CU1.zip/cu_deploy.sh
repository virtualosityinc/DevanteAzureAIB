#!/bin/bash 
######################################################################################### 
# 
# AutoDeploy dependencies for CU Linux Agent. 
# Currently supporting: CentOS/RHEL           6.X,7.X 
#                       Amazon Linux AMI      2018.03
# 
# Version: 0.11                               Modified:  6-aug-2018 
######################################################################################### 
export PS4='+(${BASH_SOURCE}:${LINENO}): ${FUNCNAME[0]:+${FUNCNAME[0]}(): }'
######################################################################################### 
export LANG=en_US.UTF-8 
export LANGUAGE=en_US.UTF-8 
export LC_COLLATE=C 
export LC_CTYPE=en_US.UTF-8 
######################################################################################### 
# Functions  
######################################################################################### 
       #check and only if not installed, install rpm 
function install_dep_rpm { 
       # check if rpm is installed 
       search_status=$(rpm -qa ${1} | wc -l ) 
       if [ "${search_status}" = "1" ]; then 
               echo "${1} already installed." 
       else 
               yum list --quiet ${1} > /dev/null 
               package_status=$? 
               if [ "${package_status}" = "0" ]; then 
                       ## echo "Installing ${1}" 
                       sudo_run=$(echo ${sudo_pass} | sudo -S -k -p "Installing ${1}: " yum install -y -q ${1}) 
                       sudo_status=$? 
                       if [ "${sudo_status}" != "0" ]; then 
                               echo "Failed to install ${1}"; 
                               echo "error : ${sudo_run}"; 
                               exit 1 
                       fi 
               else 
                       echo "Cannot install: ${1} is missing from repository " 
                       exit 1
               fi 
       fi 
} 

######################################################################################### 
#  Usage function
######################################################################################### 
function usage { 
       echo "Usage: $0 -p [password] -c [repo | package -r <package name>]"; 
       echo ""; 
       echo "password = Password for user running the script (must have sudo rights to run yum)"; 
       echo "repo = default install dependet repositories"; 
       echo "package = install package given"
       echo "<package name> = install <package name> on machine"; 
       echo ""; 
       ## exit 99 
}

################################################################# 
#  do we have sudo rights ? 
######################################################################################### 
function is_sudo {
#########################################################################################
# setup default package manager per os
#########################################################################################

        case ${OS} in
               CentOS*)
                        export pkg_manager="yum"
                       ;;
               RedHatEnterpriseServer|"Red Hat Enterprise Linux Server")
                        export pkg_manager="yum"
                       ;;
               "Amazon Linux AMI")
                       ## echo "no need to add additional repo's"
                        export pkg_manager="yum"
                       ;;
                ubuntu|Ubuntu)
                        export pkg_manager="apt-get"
                        ;;
        esac
#########################################################################################
# Check if we have sudo rights for the package manager 
#########################################################################################
        sudo_output=$(echo ${sudo_pass} | sudo -S -lk ${pkg_manager}) 
        sudo_exit=$? 
        if [ "${sudo_exit}" != "0" ]; then 
                printf "No sudo rights for user $(whoami):\n  ${sudo_output}\n"; 
                exit 80
        fi 
}
 
######################################################################################### 
# Check if we have WWW access 
######################################################################################### 
## check if wget exist 
function is_network {
        if [ ! -f /usr/bin/wget ]; then 
                install_dep_rpm wget 
        fi 
## if not, try to install it or exit 
        ee=$(wget --timeout 10 --spider --quiet ${check_network_link})
        if [ "$?" = "0" ]; then 
                IS_NETWORK=yes 
        else 
                IS_NETWORK=no 
                echo "No external connectivity detected. Will try to install from local repositories"
        fi 
}

######################################################################################### 
# Environment settings 
######################################################################################### 

export PATH=/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin 
check_network_link="http://dl.fedoraproject.org/pub/epel/6/x86_64/"
##RR DEP="bc sed gawk coreutils sysstat net-tools redhat-lsb" 
##RR DEPENDENCIES_7="procps-ng util-linux" 
##RR DEPENDENCIES_6="procps util-linux-ng" 
##RR sudo_pass=${1} 
##RR final_result=0 
##RR final_output="" 

######################################################################################### 
#  Decided what OS we are on, and what Major version 
######################################################################################### 

if [ -f /etc/os-release ]; then 
   # freedesktop.org and systemd 
   . /etc/os-release 
   OS=$NAME 
   VER=$VERSION_ID 
elif type lsb_release >/dev/null 2>&1; then 
   # linuxbase.org 
   OS=$(lsb_release -si) 
   VER=$(lsb_release -sr) 
elif [ -f /etc/lsb-release ]; then 
   # For some versions of Debian/Ubuntu without lsb_release command 
   . /etc/lsb-release 
   OS=$DISTRIB_ID 
   VER=$DISTRIB_RELEASE 
elif [ -f /etc/debian_version ]; then 
   # Older Debian/Ubuntu/etc. 
   OS=Debian 
   VER=$(cat /etc/debian_version) 
elif [ -f /etc/SuSe-release ]; then 
   # Older SuSE/etc. 
   OS=Suse 
elif [ -f /etc/redhat-release ]; then 
   # Older Red Hat, CentOS, etc. 
   OS=$(cat /etc/redhat-release) 
fi 

VER=$(echo ${VER} | cut -c1-1)

######################################################################################### 
# setup variables
######################################################################################### 
while (( $# )); do
        case $1 in
                -p) 
                        shift&&sudo_pass="${1}"||die
                        ;;
                -c)
                        shift&&COMMAND="${1}"||die
                        ;;
                -r)
                        shift&&package="${1}"||die
                        ;;
                *)
                        usage
                        exit 90
                        ;;
        esac
        shift
done

######################################################################################### 
# check to see if sudo_pass is empty or exit
######################################################################################### 
if [ -z "${sudo_pass}" ]; then
        echo "No Sudo Password was given"
        exit 99
fi

######################################################################################### 
# check to see if a command was given
######################################################################################### 
if [ "${COMMAND}" = "repo" ] || [ "${COMMAND}" = "package"  ]; then
        echo ""
else
        echo "No command was given"
        usage
        exit 92
fi

######################################################################################### 
# check if command is package, and no package was given
######################################################################################### 
if [ "${COMMAND}" = "package" ];then
        if [ -z "${package}" ]; then
        echo "No package was stated to be installed"
        usage
        exit 94
        fi
fi


######################################################################################### 
# main:
######################################################################################### 
case ${COMMAND} in
        package)
                install_dep_rpm ${package}
                ;;
        repo)
                is_sudo
                is_network
                ######################################################################################### 
                # Add needed repositories (EPEL / ...) if www access exist 
                ######################################################################################### 
                if [ "${IS_NETWORK}" = "yes" ]; then
                        case ${OS} in
                                CentOS*)
                                        ee=$(rpm -qa | grep epel)
                                        outp=$?
                                        if [ "${outp}" -eq "0" ];then
                                                echo "Epel is already installed"
                                        else
                                                cd /tmp
                                                wget https://dl.fedoraproject.org/pub/epel/epel-release-latest-$(rpm -E '%{rhel}').noarch.rpm
                                                echo ${sudo_pass} | sudo -S -k -p "Installing EPEL: " yum install -y ./epel-release-latest-*.noarch.rpm 
                                                if [ "$?" != "0" ]; then
                                                        echo "Could not install EPEL repo"
                                                        exit 66
                                                fi
                                        fi
                                        ;;
                                "RedHatEnterpriseServer"|"Red Hat Enterprise Linux Server")
                                        ee=$(rpm -qa | grep epel)
                                        outp=$?
                                        if [ "${outp}" -eq "0" ];then
                                                echo "Epel is already installed"
                                        else
                                                cd /tmp
                                                wget https://dl.fedoraproject.org/pub/epel/epel-release-latest-$(rpm -E '%{rhel}').noarch.rpm
                                                echo ${sudo_pass} | sudo -S -k -p "Installing EPEL:" yum install -y ./epel-release-latest-*.noarch.rpm
                                                if [ "$?" != "0" ]; then
                                                        echo "Could not install EPEL repo"
                                                        exit 66
                                                fi
                                        fi
                                        ;;
                                "Amazon Linux AMI")
                                        ## echo "no need to add additional repo's"
                                        ;;
                                *)
                                        Message="OS ${OS} not supported at the moment."
                                        exit 222
                                        ;;
                        esac
                else
                        case ${OS} in
                                CentOS*)
                                        ## echo "No need to exit"
                                        ;;
                                RedHatEnterpriseServer|"Red Hat Enterprise Linux Server")
                                        ##  echo "No need to exit"
                                        ;;
                                "Amazon Linux AMI")
                                        echo "AWS without network access - cannnot proceed."
                                        echo "Please fix network issues and continue the install."
                                        exit 222
                                        ;;
                                *)
                                        Message="OS ${OS} not supported at the moment."
                                        exit 222
                                        ;;
                        esac
                fi
                ;;
        *)
                usage
                exit 93
                ;;
esac